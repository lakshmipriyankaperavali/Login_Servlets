package com.login;

	import java.sql.*;
import java.sql.Connection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class LoginServlet
 */
//@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
private static final long serialVersionUID = 1L;

/**
* @see HttpServlet#HttpServlet()
*/
public LoginServlet() {
super();
// TODO Auto-generated constructor stub
}

/**
* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
*/
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
response.getWriter().append("Served at: ").append(request.getContextPath());
}public boolean checkUser(String username,String password) throws IOException{
boolean st=false;

try{

Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","Nitcog@915");
PreparedStatement ps=con.prepareStatement("select firstname,lasntame from log where firstname=? and lasntame=?");

ps.setString(1, username);
ps.setString(2, password);

ResultSet rs = ps.executeQuery();    

st=rs.next();

}catch(Exception e){

}
return st;

}



/**
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
*/
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub

response.setContentType("text/html");
PrintWriter out=response.getWriter();

String username = request.getParameter("text1");  
String password = request.getParameter("text2");


if(checkUser(username,password)){
System.out.println("valid");
RequestDispatcher rd=request.getRequestDispatcher("/welcome");
rd.forward(request, response);
}
else{
System.out.println("not valid");
RequestDispatcher rd=request.getRequestDispatcher("Login.html");
rd.include(request, response);
out.print("incorrect");
}




/*if(rs.next())          
out.println("Valid login credentials");        
else
out.println("Invalid login credentials");            
}*/
 




}

}
